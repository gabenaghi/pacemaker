// heart_rate_display.h
#ifndef HEART_RATE_DISPLAY_H
#define HEART_RATE_DISPLAY_H

void heart_rate_timeout(void const* args);
void print_heart_rate(void);
void heart_rate_display_thread(void);

#endif // HEART_RATE_DISPLAY_H

