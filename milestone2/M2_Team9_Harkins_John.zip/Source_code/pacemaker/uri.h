// uri.h
#ifndef URI_H
#define URI_H

void uri_thread(void);

#endif // URI_H

