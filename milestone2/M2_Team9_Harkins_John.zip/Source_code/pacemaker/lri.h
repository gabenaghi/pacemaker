// lri.h
#ifndef LRI_H
#define LRI_H

void lri_thread(void);

#endif // LRI_H

