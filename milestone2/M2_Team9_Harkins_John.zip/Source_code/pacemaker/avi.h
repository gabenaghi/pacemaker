// avi.h
#ifndef AVI_H
#define AVI_H

void avi_thread(void);

#endif // AVI_H

