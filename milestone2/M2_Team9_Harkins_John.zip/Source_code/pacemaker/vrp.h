// vrp.h
#ifndef VRP_H
#define VRP_H

void vrp_thread(void);

#endif // VRP_H

