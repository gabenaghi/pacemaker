#ifndef HEART_RESPONDER_H
#define HEART_RESPONDER_H

#include "common.h"

void responder_thread();


#endif