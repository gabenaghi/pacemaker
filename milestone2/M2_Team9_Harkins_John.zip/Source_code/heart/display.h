#ifndef HEART_DISPLAY_H
#define HEART_DISPLAY_H

#include "common.h"
#include "TextLCD.h"

void display_thread();

#endif //heart_display_h