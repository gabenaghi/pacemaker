#ifndef HEART_LED_H
#define HEART_LED_H

#include "common.h"

void led_thread();

#endif //heart_led_h