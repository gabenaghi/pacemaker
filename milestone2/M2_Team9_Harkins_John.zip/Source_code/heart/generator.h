#ifndef HEART_GENERATOR_H
#define HEART_GENERATOR_H

#include "common.h"

void generator_thread();

#endif //heart_generator_h